from flask import Flask, render_template, request
import ipaddress
import re
import socket
import requests

app = Flask(__name__)

GEO_API = "https://ipwho.is/{}"

def looks_like_ip(value):
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def valid_domain(value):
    value = value.rstrip(".").lower()
    if len(value) > 253 or "." not in value:
        return False
    label_re = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
    return all(label_re.fullmatch(label) for label in value.split("."))

def resolve_input(value):
    """Accept a public IP address or a domain name and return one public IP."""
    value = value.strip()
    if looks_like_ip(value):
        ip = ipaddress.ip_address(value)
        if not ip.is_global:
            raise ValueError("Please enter a public IP address. Private and reserved IPs cannot be geolocated reliably.")
        return str(ip), None

    domain = value.lower().rstrip(".")
    if not valid_domain(domain):
        raise ValueError("Enter a valid public IP address or domain, such as 8.8.8.8 or example.com.")

    try:
        # getaddrinfo can return IPv4 and IPv6; this sample chooses the first public result.
        answers = socket.getaddrinfo(domain, None, type=socket.SOCK_STREAM)
        for answer in answers:
            candidate = answer[4][0]
            try:
                ip = ipaddress.ip_address(candidate)
                if ip.is_global:
                    return str(ip), domain
            except ValueError:
                continue
    except socket.gaierror:
        pass

    raise ValueError("Could not resolve this domain to a public IP address. Check the spelling and try again.")

@app.route("/", methods=["GET", "POST"])
def index():
    query = ""
    result = None
    error = None

    if request.method == "POST":
        query = request.form.get("query", "").strip()
        # Allow users to paste a URL, not only a bare domain.
        query = re.sub(r"^https?://", "", query, flags=re.IGNORECASE).split("/")[0].strip()

        try:
            ip, domain = resolve_input(query)
            result = {
                "query": query,
                "domain": domain or "IP address entered directly",
                "ip": ip,
                "country": "Unavailable",
                "region": "Unavailable",
                "city": "Unavailable",
                "isp": "Unavailable",
                "latitude": None,
                "longitude": None,
                "map_url": None,
            }

            try:
                response = requests.get(
                    GEO_API.format(ip),
                    timeout=8,
                    headers={"User-Agent": "DomainLocationFinder/1.0"}
                )
                response.raise_for_status()
                data = response.json()

                if data.get("success"):
                    connection = data.get("connection") or {}
                    latitude = data.get("latitude")
                    longitude = data.get("longitude")
                    result.update({
                        "country": data.get("country") or "Unavailable",
                        "region": data.get("region") or "Unavailable",
                        "city": data.get("city") or "Unavailable",
                        "isp": connection.get("isp") or "Unavailable",
                        "latitude": latitude,
                        "longitude": longitude,
                    })
                    if latitude is not None and longitude is not None:
                        result["map_url"] = (
                            "https://www.openstreetmap.org/?mlat={}&mlon={}#map=8/{}/{}".format(
                                latitude, longitude, latitude, longitude
                            )
                        )
                else:
                    error = "The IP was found, but the location service did not return location details."
            except (requests.RequestException, ValueError):
                error = "The IP was found, but the location service could not be reached. Please try again."
        except ValueError as exc:
            error = str(exc)

    return render_template("index.html", query=query, result=result, error=error)

if __name__ == "__main__":
    # Local development only. Do not use debug=True on a public production server.
    app.run(host="127.0.0.1", port=5000, debug=True)
