# Domain Location Finder

A Flask website that accepts either a public IP address or a domain name, resolves domains to public IP addresses, and displays approximate IP geolocation details when available.

## Run on a laptop

1. Install Python 3.10+ and VS Code.
2. Open this folder in VS Code.
3. Open Terminal -> New Terminal.
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
   On Windows, if `python` does not work, try:
   ```powershell
   py -m pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python app.py
   ```
   Or on Windows:
   ```powershell
   py app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

## Publish online

Upload the project to a GitHub repository, then create a Python web service on a hosting platform such as Render. Use:
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`

## Notes

- Only public/global IPs are looked up; private and reserved IPs are rejected.
- Geolocation is approximate and cannot reveal an exact home address.
- This demo sends the looked-up IP to the public ipwho.is geolocation service. Check the provider's current terms, privacy policy, and usage limits before commercial use.
- `debug=True` is intended only for local development.
